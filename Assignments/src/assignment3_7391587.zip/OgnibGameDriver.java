import java.util.Random;
import java.util.Scanner;

public class OgnibGameDriver {
	 public static void main(String[] args) {
		 

	      OgnibGame game = new OgnibGame();
	      
	      game.startGame();
	      

	 
	      // the array now contains all unique random values
	      //for (int i = 0; i < board.length; ++i) {
	      //      System.out.print(board[i] + " ");
	      //}

	      // sort the array afterward
	      // then code the game!
	      
	    }
}
